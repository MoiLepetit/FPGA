/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <unistd.h>
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
#include "xscutimer.h"

XScuTimer Timer;

#define TIMER_LOAD_VALUE 325000000; // Frequency of the CPU

int main()
{
    init_platform();

    // Initialize of parameters
    XGpio push; // Button
    int psb_check; // Value of the button use
    int tmp_psb_check = 0; // Previous value of the button use
    int count = 0; // Time counter
    u32 cpu_freq = TIMER_LOAD_VALUE; // CPU Frequency
    float time;

    // Timer definitions
    XScuTimer_Config *TimerConfig;
   	XScuTimer *TimerInstancePtr = &Timer;

    print("----| StopWatch |----\n\r");

    // Initialize buttons
    XGpio_Initialize(&push, XPAR_XTTCPS_0_DEVICE_ID);
    XGpio_SetDataDirection(&push, 1, 0xffffffff);

   // Initialize the timer
   TimerConfig = XScuTimer_LookupConfig(XPAR_PS7_SCUTIMER_0_DEVICE_ID);
   XScuTimer_CfgInitialize(TimerInstancePtr, TimerConfig, TimerConfig->BaseAddr);
   XScuTimer_SelfTest(TimerInstancePtr);

   // Load timer with the time expiration
   u32 time_expired = (cpu_freq) / 1000; // To get a precision of 1ms
   XScuTimer_LoadTimer(TimerInstancePtr, time_expired);
   XScuTimer_EnableAutoReload(TimerInstancePtr);

    while(1){
    	psb_check = XGpio_DiscreteRead(&push, 1);
    	if (psb_check > 0 && tmp_psb_check != psb_check){
    		if(psb_check == 2){
				xil_printf("Start\r\n");
				// Start the timer
				count = 0;
				XScuTimer_Start(TimerInstancePtr);
				tmp_psb_check = psb_check;
    		}
    		if(psb_check == 8){
    			xil_printf("Stop\r\n");
    			// Stop the timer
    			XScuTimer_Stop(TimerInstancePtr);
    			time = (float)(count) / 1000;
    			// Print the counter and the time
    			printf("Count : %d\n", count);
    			printf("Timer : %.3f s\n", time);
    			tmp_psb_check = psb_check;
    		}
		}
    	if(XScuTimer_IsExpired(TimerInstancePtr)) { // Every ms the timer expired
    		XScuTimer_ClearInterruptStatus(TimerInstancePtr);
			count++; // Count the number of expiration
    	}
    }

    cleanup_platform();
    return 0;
}
